Aplicaci�n:
	OK--- Registro y listado de producto
	OK--- Tiene que tener 6 campos a parte del id
	OK--- Usar controles para el registro y listado: Usado ComboBox y Radiobutton)
	OK--- En vez de listar con JTextArea, hacerlo con JList
	OK--- Dar mensaje de error si alg�n campo est� vac�o, y no guardar curso.
	OK--- Vaciar las entradas de texto despu�s de registrar
	OK--- Crear panel de Bienvenida
	OK--- Editar y Borrar producto
	OK--- Permitir introducir comas en campo precio (double)
	OK--- Scroll en JList
	Ok--- Comprobaci�n campos int y double (horas y precio) con try/catch